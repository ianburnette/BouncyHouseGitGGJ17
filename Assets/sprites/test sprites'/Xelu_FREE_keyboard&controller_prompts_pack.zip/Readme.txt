Hey there!

Hope you make good use of this pack. You can use all these assets in any project you want to (be it commercial or not).
All of the assets are in the public domain under Creative Commons 0 (CC0)

In this pack you will find over 500 buttons including:

Xbox 360 controller
Xbox One controller
Play Station 3 controller
Play Station 4 controller
Play Station Move
PS Vita
Vive Controller
Oculus Controllers & Remote
Wii Controller
Wii U Controller
Nintentdo Switch
Steam Controller (Updated to commercial version)
Ouya
Keyboard and mouse buttons (Both in black and white including blanks)
Directional arrows for thumb sticks and movement keys
Touch Screen Gestures

----------------------------------

I am "Nicolae Berbece" (also known as Xelu), I founded "Those Awesome Guys" and made "Move or Die" which is out right now on Steam.
You can contact me at nick@thoseawesomeguys.com

Feel free to credit me in case you use anything in this pack, but don't worry, I won't mind if you don't. ;)

Please share this pack with other fellow developers in need of such assets! In the spirit of good old chain mail, if you share this pack with 5 fellow devs, your game's steam review score will rise by 7% and a notable twitch streamer will pick it up for his stream.

Keep making awesome things!!!

~Nick





Here is a semi-updated list of games using these prompts:
----------------------------
Mega Man Legacy
Postal 2
Postal Redux
RWBY
Heat Signature
Turbo Dismount
Fallen Legion
20XX
Obduction
Battle Chef Brigade
Phantom Brigade
Redirection
Defender's Quest
Roundabout
Arena 3D
Super Comboman
Disc Jam
Mayan Death Robots
Sentris
Unbox
Induction
Shadow Warrior 2
The Flock
Deputy dangle
Tumblestone
Solbrain Knight of Darkness
SSMP
Distance
Idarb
Earthlock
Everspace
Pylon Rogue
The Church in the darkness
Sword n' Board